'''
Created on 28-Jan-2018

@author: senthilkumar
'''

from distutils.core import setup

setup(
    name = 'palindrome',
    version = '1.0',
    py_modules=['palindrome'],
    
    author = 'senthilkumar',
    author_email = 'senth@gmail.com',
    description = 'A module finding palindrome',
    license = 'Public domain',
    keywords = 'example',
    
    )
